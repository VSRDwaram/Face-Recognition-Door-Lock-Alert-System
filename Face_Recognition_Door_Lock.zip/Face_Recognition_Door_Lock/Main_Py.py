import cv2
import os
import face_recognition
import requests
import serial
import time

# Telegram Bot Credentials
BOT_TOKEN = "8071764341:AAFJFFialdjHuXboGaWxancrQkSXz4uwl6Y"
CHAT_ID = "6265036456"

# Serial Communication Setup (Change COM port accordingly)
ESP32_PORT = "COM8"  # Change to your ESP32 port (e.g., /dev/ttyUSB0 for Linux)
BAUD_RATE = 115200

ser = serial.Serial(ESP32_PORT, BAUD_RATE, timeout=1)
time.sleep(2)  # Allow time for the serial connection to establish

def send_telegram_message(message):
    """Send a message to the Telegram bot."""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": message}
    requests.post(url, json=payload)

def load_images_from_folder(folder):
    """Load known faces from the folder, ensuring only image files are processed."""
    encodings = []
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        
        # Check if the file is an image (by extension)
        if not filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue
        
        try:
            img = face_recognition.load_image_file(img_path)
            encoding = face_recognition.face_encodings(img)
            if encoding:
                encodings.append(encoding[0])
        except Exception as e:
            print(f"Error processing image {filename}: {e}")
    
    return encodings

def compare_faces(captured_face_encoding, known_faces):
    """Compare captured face encoding with known faces."""
    matches = face_recognition.compare_faces(known_faces, captured_face_encoding)
    return any(matches)

def detect_faces():
    """Detect faces and compare them with known faces."""
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return
    
    predefined_folder = r"C:\Users\n1802\Desktop\Shiva's_Frnd_Project\Gate_image_data"
 # Folder with known faces
    known_faces = load_images_from_folder(predefined_folder)
    
    save_folder = "detected_faces"
    os.makedirs(save_folder, exist_ok=True)
    
    face_saved = False
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break
        
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
        
        if len(face_encodings) == 1 and not face_saved:
            top, right, bottom, left = face_locations[0]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            face = frame[top:bottom, left:right]
            face_filename = os.path.join(save_folder, "detected_face.jpg")
            success = cv2.imwrite(face_filename, face)

            if success:
                print(f"Face saved as {face_filename}")
                if compare_faces(face_encodings[0], known_faces):
                    print("Match found!")
                    send_telegram_message("Match found! Someone recognized at the gate.")  # Send alert to Telegram
                    ser.write(b"MATCH\n")  # Send match signal to ESP32
                else:
                    print("No match found.")
                    send_telegram_message("No match found! Unauthorized person detected at the gate.")
                    ser.write(b"NO_MATCH\n")  # Send no-match signal to ESP32
            else:
                print("Error: Failed to save the image")
            
            face_saved = True
        
        cv2.imshow('Face Detection', frame)
        
        if len(face_encodings) == 0:
            face_saved = False
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    ser.close()

if __name__ == "__main__":
    detect_faces()

